# RONG LAB Android Beta 0.4

此為可透過 GitHub Actions 在雲端編譯 Android Debug APK 的**原始碼**，不是已編譯 APK。

## 手機操作
1. 在 GitHub 建立私人或公開儲存庫，預設分支 main。
2. 解壓 ZIP，將 `www/`、`.github/workflows/android-apk.yml`、`package.json`、`capacitor.config.json` 上傳到儲存庫根目錄。注意 `.github` 是隱藏資料夾，手機檔案管理器可能需要啟用顯示隱藏檔。
3. GitHub Actions > Build RONG LAB Android APK > Run workflow；若工作流程因上傳而自動啟動，無需重複執行。
4. 等候雲端建置完成，打開該次執行的 Artifacts，下載 `RONG-LAB-Beta-0.4-debug-APK` 壓縮檔，解壓得到 `app-debug.apk`。
5. 在 Android 手機安裝；必要時授權檔案管理器安裝未知來源 App。僅安裝自己建置的檔案。

## 限制
- APK 尚未實際編譯或手機測試，工作流程需依 GitHub Actions 結果排錯。
- PLAY 挑戰分享目前尚未有公開 HTTPS 網站，不能直接以 App 內部連結讓朋友跨裝置開啟。
- 尚未整合 AdMob SDK；不含廣告，不會產生收益。
- DAILY 資料儲存在本機 WebView，清除 App 資料會遺失。
- Debug APK 僅供測試，不可直接上架 Google Play。正式版需 release 簽署並輸出 AAB。
