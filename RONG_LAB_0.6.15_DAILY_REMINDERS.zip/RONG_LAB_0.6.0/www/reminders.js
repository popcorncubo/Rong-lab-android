'use strict';
(function(){
 const messages=['您今天開始任務了嗎？0a0','建立自己的每日任務 ouo','完成自己每日的財務收入紀錄','記錄今天自己的運動成果！'];
 const base=820000,count=90,testId=820100;
 const enabledKey='ronglab-reminders-enabled-v1',dayKey='ronglab-reminders-day-v1';
 let busy=false;
 function status(message){const el=document.getElementById('reminderStatus');if(el)el.textContent=message}
 function localDay(){const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}
 function plugin(){const cap=window.Capacitor;if(!cap||!cap.isNativePlatform||!cap.isNativePlatform()||typeof cap.registerPlugin!=='function')throw Error('請在 Android App 中使用提醒');return cap.registerPlugin('LocalNotifications')}
 function entries(){const now=new Date(),out=[];let n=0;for(let day=0;day<45;day++){for(const hour of [9,14]){const date=new Date(now.getFullYear(),now.getMonth(),now.getDate()+day,hour,0,0,0),id=base+n++;if(date<=now)continue;out.push({id,title:'RONG LAB 提醒',body:messages[Math.floor(Math.random()*messages.length)],schedule:{at:date,allowWhileIdle:true}})}}return out}
 async function cancel(n){await n.cancel({notifications:Array.from({length:count+1},(_,i)=>({id:i===count?testId:base+i}))})}
 async function arrange(n){await cancel(n);const notifications=entries();await n.schedule({notifications});localStorage.setItem(dayKey,localDay())}
 async function enable(){if(busy)return;busy=true;try{status('正在設定通知…');const n=plugin();let p=await n.checkPermissions();if(p.display!=='granted')p=await n.requestPermissions();if(p.display!=='granted'){status('未獲得通知權限，請到手機設定開啟 RONG LAB 通知。');return}await arrange(n);localStorage.setItem(enabledKey,'yes');status('提醒已設定：每天 09:00 和 14:00。系統可能延遲。')}catch(e){status('設定失敗：'+(e.message||e))}finally{busy=false}}
 async function disable(){if(busy)return;busy=true;try{const n=plugin();await cancel(n);localStorage.removeItem(enabledKey);localStorage.removeItem(dayKey);status('每日提醒已關閉。')}catch(e){status('關閉失敗：'+(e.message||e))}finally{busy=false}}
 async function test(){if(busy)return;busy=true;try{const n=plugin();let p=await n.checkPermissions();if(p.display!=='granted')p=await n.requestPermissions();if(p.display!=='granted'){status('未獲得通知權限。');return}await n.cancel({notifications:[{id:testId}]});await n.schedule({notifications:[{id:testId,title:'RONG LAB 測試提醒',body:'通知設定完成！0a0',schedule:{at:new Date(Date.now()+10000),allowWhileIdle:true}}]});status('已安排測試通知，請等待約 10 秒；系統可能延遲。')}catch(e){status('測試失敗：'+(e.message||e))}finally{busy=false}}
 document.getElementById('reminderEnable').onclick=enable;document.getElementById('reminderDisable').onclick=disable;document.getElementById('reminderTest').onclick=test;
 status(localStorage.getItem(enabledKey)==='yes'?'已啟用提醒；可用測試通知確認手機設定。':'尚未啟用提醒。');
 async function refresh(){if(busy||localStorage.getItem(enabledKey)!=='yes'||localStorage.getItem(dayKey)===localDay())return;busy=true;try{const n=plugin(),p=await n.checkPermissions();if(p.display!=='granted'){status('通知權限未開啟，請到手機設定允許通知。');return}await arrange(n);status('提醒已更新：每天 09:00 和 14:00。')}catch(e){status('提醒更新失敗，請重新開啟：'+(e.message||e))}finally{busy=false}}
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});refresh();
})();
