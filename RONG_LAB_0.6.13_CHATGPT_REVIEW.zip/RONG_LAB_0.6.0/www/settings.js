'use strict';
(function(){
 const DEFAULT={language:'zh-Hant',theme:'blue',motion:true};
 const oldPrefs=state.appPreferences&&typeof state.appPreferences==='object'?state.appPreferences:{};
 let preferences={...DEFAULT,...oldPrefs};
 if(!['zh-Hant','zh-Hans','en'].includes(preferences.language))preferences.language=DEFAULT.language;
 if(!['blue','violet','teal'].includes(preferences.theme))preferences.theme=DEFAULT.theme;
 if(typeof preferences.motion!=='boolean')preferences.motion=DEFAULT.motion;
 const originalText=new WeakMap(),originalPlaceholder=new WeakMap();let observer;
 // Text owned by users or challenge payloads must retain the user's spelling.
 const protectedSelector=['.task','.module-record','#greeting','#profileButton','#quizTitle','#quizChoices','#answerReview','#customDraft','#savedChallenges','#cqPrompt','#cqInputs','#customReview','#businessProductList','#businessShowcase','#businessOrderList','#businessNoteList','#taskList','#shiftList','#goalList','#moneyList','#growthList','#mList','#hList','#pList','#bList','#eList','#boProduct','input','textarea','[contenteditable="true"]','script','style'].join(',');
 function isProtected(node){const el=node.nodeType===1?node:node.parentElement;return !el||!!el.closest(protectedSelector)}
 function translateDOM(){
  if(observer)observer.disconnect();
  try{
   const simplify=preferences.language==='zh-Hans',english=preferences.language==='en',convert=window.RongSettingsNative.toSimplified;
   const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
   while((n=walker.nextNode())){
    if(!n.nodeValue.trim())continue;
    if(isProtected(n)){const el=n.parentElement,source=n.nodeValue.trim();
      const known=Object.prototype.hasOwnProperty.call(window.RongEnglish.messages,source);
      const emptyList=el&&(['hList','mList','pList','bList','eList','taskList','shiftList','goalList','moneyList','growthList'].includes(el.id))&&el.children.length===0&&known;
      const fixedWelcome=el&&el.id==='greeting'&&source==='歡迎使用 RONG LAB';
      const customControl=el&&el.closest('#customDraft')&&(el.matches('h3')||el.matches('label'))&&(known||/^第\s*\d+\s*題/.test(source));
      const buttonOrQuiz=el&&(el.closest('button')||el.closest('#quizTitle')||el.closest('#quizChoices'))&&!el.closest('#cqInputs');
      const allowed=originalText.has(n)||(preferences.language==='en'&&el&&(customControl||(known&&(emptyList||fixedWelcome||buttonOrQuiz))));if(!allowed)continue;}
    if(!originalText.has(n))originalText.set(n,n.nodeValue);
    const source=originalText.get(n),weekday=n.parentElement?.matches('.calendar > span')?{'日':'Sun','一':'Mon','二':'Tue','三':'Wed','四':'Thu','五':'Fri','六':'Sat'}[source.trim()]:null,result=simplify?convert(source):english?(weekday||window.RongEnglish.translate(source)):source;
    if(n.nodeValue!==result)n.nodeValue=result;
   }
   for(const el of document.querySelectorAll('input[placeholder],textarea[placeholder]')){
    if(!originalPlaceholder.has(el))originalPlaceholder.set(el,el.getAttribute('placeholder'));
    const source=originalPlaceholder.get(el),result=simplify?convert(source):english?window.RongEnglish.translate(source):source;
    if(el.getAttribute('placeholder')!==result)el.setAttribute('placeholder',result);
   }
   document.documentElement.lang=preferences.language;
  }finally{if(observer)observer.observe(document.body,{childList:true,subtree:true,characterData:true})}
 }
 function captureOptionValues(){for(const o of document.querySelectorAll('option'))if(!o.hasAttribute('value'))o.setAttribute('value',o.textContent)}
 function refreshLanguage(){captureOptionValues();translateDOM()}
 observer=new MutationObserver(()=>refreshLanguage());
 function applyPreferences(){document.body.dataset.theme=preferences.theme;document.body.dataset.motion=preferences.motion?'on':'off';$('settingsLanguage').value=preferences.language;$('settingsTheme').value=preferences.theme;$('settingsMotion').checked=preferences.motion;refreshLanguage()}
 function changePreferences(next){
  const before=preferences,old=state.appPreferences;
  preferences={...preferences,...next};state.appPreferences={...preferences};
  if(!save()){state.appPreferences=old;preferences=before;applyPreferences();text($('settingsSaveStatus'),'儲存失敗，設定未變更。');return}
  applyPreferences();text($('settingsSaveStatus'),'已儲存在這台手機。');refreshLanguage();
 }
 $('settingsLanguage').onchange=()=>changePreferences({language:$('settingsLanguage').value});
 $('settingsTheme').onchange=()=>changePreferences({theme:$('settingsTheme').value});
 $('settingsMotion').onchange=()=>changePreferences({motion:$('settingsMotion').checked});
 const installedVersion='1.0.14';let currentVersion=installedVersion;
 async function showInstalled(){
  try{const info=await window.RongSettingsNative.getAppInfo();if(info&&typeof info.version==='string'){currentVersion=info.version;text($('settingsVersion'),info.version+(info.build?'（版本代碼 '+info.build+'）':''));if(info.name)text($('settingsAppName'),info.name)}else text($('settingsVersion'),installedVersion+'（網頁預覽）')}
  catch{text($('settingsVersion'),installedVersion+'（來源設定，無法讀取安裝版本）')}
 }
 function versionParts(v){const m=String(v).trim().match(/^v?(\d+)\.(\d+)\.(\d+)$/);return m?m.slice(1).map(Number):null}
 function compare(a,b){const x=versionParts(a),y=versionParts(b);if(!x||!y)return null;for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i]?1:-1;return 0}
 async function checkUpdate(){
  const button=$('settingsCheckUpdate'),status=$('settingsUpdateStatus');button.disabled=true;text(status,'正在檢查公開版本…');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
   const response=await fetch('https://api.github.com/repos/popcorncubo/Rong-lab-android/releases/latest',{headers:{Accept:'application/vnd.github+json'},credentials:'omit',signal:controller.signal});
   if(response.status===404){text(status,'目前查不到公開 Release，無法確認是否有更新。Actions 測試版不會自動列在這裡。');return}
   if(!response.ok)throw Error('無法連線至公開版本資訊');
   const release=await response.json(),cmp=compare(release.tag_name,currentVersion);
   if(cmp===null || versionParts(release.tag_name)[0]!==versionParts(currentVersion)[0]){text(status,'找到公開版本 '+String(release.tag_name||'')+'，但版本編號可能使用不同規則，無法自動比對；請自行查看版本頁面。');return}
   if(cmp>0)text(status,'有較新的公開版本：'+release.tag_name+'。請開啟公開版本頁面查看。');
   else text(status,'公開 Release 未顯示比目前更新的版本；Actions 測試版仍需另外確認。');
  }catch{text(status,'無法檢查更新，請確認網路後再試；目前不能判定是否為最新版。')}
  finally{clearTimeout(timer);button.disabled=false}
 }
 $('settingsCheckUpdate').onclick=checkUpdate;
 const originalAlert=window.alert,originalConfirm=window.confirm,originalPrompt=window.prompt;
 const translateDialog=message=>preferences.language==='en'?window.RongEnglish.translate(message):preferences.language==='zh-Hans'?window.RongSettingsNative.toSimplified(String(message)):String(message);
 window.alert=message=>originalAlert.call(window,translateDialog(message));
 window.confirm=message=>originalConfirm.call(window,translateDialog(message));
 window.prompt=(message,defaultValue)=>originalPrompt.call(window,translateDialog(message),defaultValue);
 let checkedOnce=false;
 window.openSettings=function(){
  const customActive=!$('customChallenge').classList.contains('hide')&&(customMode==='play'||(customMode==='builder'&&draftQuestions.length>0));
  const originalActive=!$('play').classList.contains('hide')&&!$('quiz').classList.contains('hide');
  if((customActive||originalActive)&&!confirm('開啟設定會離開目前尚未完成的挑戰，確定繼續？'))return;
  if(customActive)leaveCustom();else if(originalActive)restart();
  show('settings');applyPreferences();showInstalled();if(!checkedOnce){checkedOnce=true;checkUpdate()}
 };
 // Imported preferences are not applied silently; they take effect on restart.
 applyPreferences();
})();
