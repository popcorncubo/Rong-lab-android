RONG LAB Beta 0.6.0 — Android 1.0.1

此 ZIP 包含原本的 0.5.1 Capacitor 原始碼及新增模組。
GitHub Actions 原流程只允許根目錄有一個 ZIP；請先保留舊 ZIP 的備份，並確保儲存庫根目錄僅有這一個 ZIP。
重要：單純上傳 ZIP 不會修改 GitHub Actions。若要 APK 顯示 1.0.1，請將 ZIP 內 build-apk-1.0.1.yml 的完整內容貼到儲存庫 .github/workflows/build-apk.yml，再執行 Actions。此流程設定 versionName 1.0.1、versionCode 2；請確認舊版 versionCode 確實為 1，若舊版代碼 >=2 則新版須大於舊版。

直接更新需相同 applicationId app.ronglab.dailyplay、較大 versionCode、相同簽章。原 GitHub Actions 預設使用臨時 debug keystore，每次全新 runner 可能使用不同簽章；因此無法保證安裝覆蓋。需要原本簽署金鑰並在 GitHub Actions 安全配置，才可驗證升級。不要卸載舊版 App，卸載可能刪除資料。先在舊版個人資料頁匯出並確認備份。

資料保存在原本本機鍵 ronglab-local-v051，新增模組欄位隨原有 JSON 備份一起匯出；原版匯入會取代現有資料，請先匯出備份。未測試實機升級或 Android 備份匯出。

SHIFT 為月曆、日夜班、跨日計時、時薪估算；健康紀錄為文字型；商業展示為本機清單、交易為手動營運紀錄，未接金流；學習為技能分鐘追蹤。此版本為整合測試版，沒有雲端登入、公開商店、自動付款或自動驗款。
