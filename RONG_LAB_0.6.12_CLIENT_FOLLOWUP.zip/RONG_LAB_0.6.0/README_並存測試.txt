RONG LAB 並存測試版

此專案使用新的 appId app.ronglab.dailyplay.preview，名稱 RONG LAB 測試版；可與原本 app.ronglab.dailyplay 並存，不會覆蓋舊版。資料空間獨立，不會自動帶入舊紀錄。
請保留舊 App；若舊版可用，先匯出 JSON 並確認備份確實存在，再在本測試版匯入。匯入會取代測試版現有本機資料。
保持 GitHub 根目錄只有一個來源 ZIP；原有已運作的編譯工作流程可沿用。此為 debug APK，後續每次 GitHub 工作流程可能使用不同的簽章；要讓測試版之後也能直接覆蓋更新，仍需妥善保管並持續使用同一簽章金鑰。
不保證與使用者裝置相容，尚未於真機測試。
