import {Converter} from 'opencc-js/t2cn';
import {Capacitor} from '@capacitor/core';
import {App} from '@capacitor/app';
window.RongSettingsNative={toSimplified:Converter({from:'tw',to:'cn'}),getAppInfo:async()=>Capacitor.isNativePlatform()?App.getInfo():null};
