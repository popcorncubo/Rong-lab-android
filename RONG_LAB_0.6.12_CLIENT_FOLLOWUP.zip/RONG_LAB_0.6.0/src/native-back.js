import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
window.RongNativeBack = {exit: () => App.exitApp()};
if (Capacitor.isNativePlatform()) App.addListener('backButton', () => window.RongBack.handle());
