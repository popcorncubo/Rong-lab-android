'use strict';
// The route stack records existing screen actions; data stays in the original store.
(function(){
 const screens=['home','daily','tasks','shifts','goals','money','growth','profile','play','areas','areaShift','areaHealth','areaBusiness','areaEducation','customChallenge','settings'];
 let stack=[],replaying=false,lastBack=0;
 const visible=()=>screens.find(id=>document.getElementById(id)&&!document.getElementById(id).classList.contains('hide'))||'home';
 const snap=()=>{const id=visible();return {id,business:id==='areaBusiness'?businessTab:null}};
 const same=(a,b)=>a.id===b.id&&a.business===b.business;
 function record(before){if(replaying)return;const after=snap();if(!same(before,after)){if(after.id==='home'){stack=[];return}if(stack.length&&same(stack[stack.length-1],after))stack.pop();else stack.push(before);if(stack.length>40)stack.shift()}}
 const baseShow=show;show=function(id){const before=snap();baseShow(id);record(before)};
 const baseAreas=showAreas;showAreas=function(){const before=snap();baseAreas();record(before)};
 const baseModule=openModule;openModule=function(id){const before=snap();baseModule(id);record(before)};
 const baseBiz=bizOpen;bizOpen=function(tab){const before=snap();baseBiz(tab);record(before)};
 function pendingChallenge(){const id=visible();if(id==='customChallenge')return customMode==='play'||(customMode==='builder'&&draftQuestions.length>0);if(id==='play')return !$('quiz').classList.contains('hide');return false}
 function restore(target){if(target.id==='areaBusiness'){baseModule('business');if(target.business)baseBiz(target.business)}else if(target.id==='areas')baseAreas();else if(target.id==='areaShift')baseModule('shift');else if(target.id==='areaHealth')baseModule('health');else if(target.id==='areaEducation')baseModule('education');else if(target.id==='customChallenge'){baseShow('play')}else baseShow(target.id)}
 function fallback(id){if(['tasks','shifts','goals','money','growth'].includes(id))return{id:'daily'};if(['areaShift','areaHealth','areaBusiness','areaEducation'].includes(id))return{id:'areas'};if(id==='customChallenge')return{id:'play'};return{id:'home'}}
 function back(){
  const now=Date.now();if(now-lastBack<250)return;lastBack=now;
  if(pendingChallenge()&&!confirm('返回會離開目前尚未完成的挑戰，確定返回？'))return;
  const current=snap();if(current.id==='areaBusiness'&&businessTab!=='overview'&&!stack.some(x=>x.id==='areaBusiness')){replaying=true;try{baseBiz('overview')}finally{replaying=false}return}if(current.id==='home'&&!stack.length){if(confirm('要離開 RONG LAB 嗎？'))window.RongNativeBack?.exit();return}
  if(current.id==='customChallenge'){customPayload=null;restart()}
  if(current.id==='play'&&!$('quiz').classList.contains('hide'))restart();
  let target=stack.pop()||fallback(current.id);while(stack.length&&same(target,current))target=stack.pop();
  // Previous custom challenge and quiz screens cannot safely be reconstructed.
  if(target.id==='customChallenge')target={id:'play'};
  replaying=true;try{restore(target)}finally{replaying=false}
 }
 window.RongBack={handle:back};
})();
