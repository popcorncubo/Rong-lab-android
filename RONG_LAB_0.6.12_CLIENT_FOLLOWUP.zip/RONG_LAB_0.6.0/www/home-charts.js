'use strict';
// Home trends are read-only views over the existing single source of truth.
(function(){
 const oldRender=renderHomeOverview;
 function amount(value){const n=Number(value);return Number.isFinite(n)&&n>0?n:0}
 function totalsFor(key){
  const shifts=state.shifts.filter(x=>typeof x.date==='string'&&x.date.startsWith(key)&&x.type!=='休假'&&x.completed===true);
  const money=state.money.filter(x=>typeof x.date==='string'&&x.date.startsWith(key)&&x.type==='income');
  return {work:shifts.reduce((n,x)=>n+amount(x.dailyPay),0),manual:money.reduce((n,x)=>n+amount(x.amount),0),business:money.filter(x=>x.source==='business-order').reduce((n,x)=>n+amount(x.amount),0),workRecords:shifts.filter(x=>amount(x.dailyPay)>0).length,manualRecords:money.length,businessRecords:money.filter(x=>x.source==='business-order').length};
 }
 function makeLineChart(months,series){
  const root=document.createElement('div');root.className='chart-plot';
  const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 320 130');svg.setAttribute('aria-hidden','true');
  const line=(tag,attrs)=>{const el=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))el.setAttribute(k,String(v));svg.append(el);return el};
  for(const y of [18,55,92])line('line',{x1:14,x2:306,y1:y,y2:y,class:'chart-grid'});
  const max=Math.max(1,...series.flatMap(s=>s.values));
  series.forEach(s=>{const points=s.values.map((v,i)=>[18+i*56.5,92-74*v/max]);line('polyline',{points:points.map(p=>p.join(',')).join(' '),class:'chart-line',stroke:s.color});points.forEach(([x,y])=>line('circle',{cx:x,cy:y,r:3.2,fill:s.color}))});
  months.forEach((m,i)=>{const e=line('text',{x:18+i*56.5,y:115,'text-anchor':'middle',class:'chart-axis'});e.textContent=m.slice(5)});
  root.append(svg);return root;
 }
 function createTitle(card,label,month,current){card.append(node('h2',label),node('div',month,'muted'),node('div',moneyFmt(current),'chart-value'))}
 function createLegend(card,items){const el=node('div',undefined,'chart-legend');items.forEach(([name,color])=>{const label=node('span');const dot=node('i',undefined,'chart-dot');dot.style.background=color;dot.setAttribute('aria-hidden','true');label.append(dot,document.createTextNode(name));el.append(label)});card.append(el)}
 function createTable(months,rows,columns){const details=document.createElement('details');const sum=node('summary','查看每月數據');details.append(sum);const table=node('table',undefined,'chart-table'),thead=document.createElement('thead'),tr=document.createElement('tr');for(const text of ['月份',...columns.map(x=>x[0])])tr.append(node('th',text));thead.append(tr);table.append(thead);const body=document.createElement('tbody');months.forEach((m,i)=>{const tr=document.createElement('tr');tr.append(node('td',m));for(const [_,prop] of columns)tr.append(node('td',moneyFmt(rows[i][prop])));body.append(tr)});table.append(body);details.append(table);return details}
 function renderHomeCharts(){
  const root=$('homeCharts');root.replaceChildren();const current=dateLocal().slice(0,7),months=financeMonths(current),rows=months.map(totalsFor),latest=rows[rows.length-1];
  const biz=node('section',undefined,'card home-chart');createTitle(biz,'商業收款趨勢',current,latest.business);biz.append(node('p','本月手動確認的商業收款','muted'));createLegend(biz,[['商業收款','#63d6be']]);
  biz.append(makeLineChart(months,[{values:rows.map(x=>x.business),color:'#63d6be'}]));if(!rows.some(x=>x.businessRecords))biz.append(node('p','最近六個月沒有商業收款紀錄。','muted chart-empty'));
  biz.append(node('p','僅計入商業訂單中手動確認並記帳的收入；不是金流自動驗款。','notice chart-note'),createTable(months,rows,[['商業收款','business']]));const businessButton=btn('查看商業管理',()=>openModule('business'));businessButton.classList.add('chart-open');biz.append(businessButton);
  const income=node('section',undefined,'card home-chart');createTitle(income,'收入趨勢',current,latest.work);income.append(node('p','本月工作應得薪資','muted'));createLegend(income,[['工作應得','#a99bff'],['手動收入','#f1c477']]);
  income.append(makeLineChart(months,[{values:rows.map(x=>x.work),color:'#a99bff'},{values:rows.map(x=>x.manual),color:'#f1c477'}]));if(!rows.some(x=>x.workRecords||x.manualRecords))income.append(node('p','最近六個月沒有已完成薪資或有日期的收入紀錄。','muted chart-empty'));
  income.append(node('p','工作應得來自已完成班次，不代表已入帳；手動收入包含商業收款，兩條線不相加。沒有日期的舊收入不納入月圖。','notice chart-note'),createTable(months,rows,[['工作應得','work'],['手動收入','manual']]));const incomeButton=btn('查看收入報告',()=>show('money'));incomeButton.classList.add('chart-open');income.append(incomeButton);root.append(biz,income);
 }
 renderHomeOverview=function(){oldRender();renderHomeCharts()};
 renderHomeCharts();
})();
