RONG LAB Local Beta 0.5.1

Offline app. Five DAILY modules, PLAY bottom navigation, local profile, JSON export/import. No authentication or cloud sync.

Build via Capacitor 7 and GitHub Actions.
