import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
window.challengeExport = async (content, filename) => {
  const name = filename || 'RONG-LAB-challenge-' + Date.now() + '.json';
  if (Capacitor.isNativePlatform()) {
    const file = await Filesystem.writeFile({path:name, directory:Directory.Cache, encoding:Encoding.UTF8, data:content});
    await Share.share({title:'RONG LAB',files:[file.uri],dialogTitle:'分享或另存檔案'});
    return '已開啟系統分享；請自行選擇儲存位置或分享對象。';
  }
  const a=document.createElement('a'),u=URL.createObjectURL(new Blob([content],{type:'application/json'}));a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000);return '已開始下載，請確認手機檔案是否儲存成功。';
};
