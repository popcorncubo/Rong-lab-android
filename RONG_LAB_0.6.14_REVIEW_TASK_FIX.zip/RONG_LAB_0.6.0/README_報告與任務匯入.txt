RONG LAB 0.6.14（Android 1.0.15）

個人資料→ChatGPT 紀錄審查。匯出時會開啟系統分享，請選擇儲存至檔案；也可複製文字給 ChatGPT。App 本身沒有保證直接下載到下載資料夾。選擇 ChatGPT 回傳之審查結果 JSON 後，會自動新增報告和任務，同名任務不重複加入，不覆蓋其他資料。舊式純文字僅保存報告，不會自動產生任務。

要求 ChatGPT 輸出 UTF-8 JSON 檔：{"kind":"rong-lab-review-result","version":1,"report":"報告","tasks":[{"text":"任務","category":"工作"}]}。分類限生活、工作、學習、運動、其他。

保留既有簽章；更新前請確認備份。分享檔儲存在暫存區，Android 可能自行清除，需自行另存。沒有真機及 APK 編譯測試。